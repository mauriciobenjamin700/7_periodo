const { Web3 } = require('web3');

// Create Web3 instance
const web3 = new Web3('https://rpc.api.moonbase.moonbeam.network');

web3.eth.getGasPrice()
.then(console.log);